"""E-Commerce Sales and Customer Behavior Analysis - Flask app.
Run:  python app.py   then open http://127.0.0.1:5000
"""
import os

import pandas as pd
from flask import Flask, redirect, render_template, request, url_for

from analysis import analyse, clean, sample_data

app = Flask(__name__)
BASE = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(BASE, "uploads", "current.csv")


def save(df):
    os.makedirs(os.path.dirname(DATA_FILE), exist_ok=True)
    df.to_csv(DATA_FILE, index=False)


@app.route("/", methods=["GET", "POST"])
def index():
    error = None
    if request.method == "POST":
        try:
            if request.form.get("action") == "sample":
                raw = sample_data()
            else:
                f = request.files.get("file")
                if not f or not f.filename:
                    raise ValueError("Please choose a CSV or Excel file.")
                raw = (pd.read_excel(f) if f.filename.lower().endswith((".xlsx", ".xls"))
                       else pd.read_csv(f))
            df, report = clean(raw)
            if df.empty:
                raise ValueError("No valid rows left after cleaning.")
            save(df)
            return redirect(url_for("dashboard", **{k: v for k, v in report.items()}))
        except Exception as e:  # show friendly message to the user
            error = str(e)
    return render_template("index.html", error=error)


@app.route("/dashboard")
def dashboard():
    if not os.path.exists(DATA_FILE):
        return redirect(url_for("index"))
    df = pd.read_csv(DATA_FILE, parse_dates=["order_date"])
    regions = sorted(df["region"].unique())
    cats = sorted(df["category"].unique())
    region, cat = request.args.get("f_region", ""), request.args.get("f_category", "")
    if region:
        df = df[df["region"] == region]
    if cat:
        df = df[df["category"] == cat]
    kpi, charts = analyse(df)
    report = {k: request.args.get(k) for k in
              ["rows_in", "duplicates_removed", "invalid_rows_removed", "missing_filled", "rows_out"]}
    return render_template("dashboard.html", kpi=kpi, charts=charts, regions=regions,
                           cats=cats, region=region, cat=cat, report=report)


if __name__ == "__main__":
    app.run(debug=True)
