# E-Commerce Sales and Customer Behavior Analysis

Web app: the user uploads e-commerce data (or uses the built-in sample) and gets a cleaned
dataset, KPI cards and six charts, with region/category filters.

## Run
    pip install -r requirements.txt
    python app.py
Open http://127.0.0.1:5000

## Input file columns
Order ID, Order Date, Customer Name, Region, Category, Sub-Category, Sales, Quantity, Discount, Profit

## Files
- app.py        Flask routes (upload, dashboard, filters)
- analysis.py   data cleaning, KPI calculation, charts (Pandas, Matplotlib, Seaborn)
- templates/    index.html (input page), dashboard.html (output)
