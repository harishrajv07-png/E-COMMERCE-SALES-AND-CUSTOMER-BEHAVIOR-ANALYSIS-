"""Cleaning, analysis and chart generation for the E-Commerce project."""
import base64
import io

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

REQUIRED = ["order_id", "order_date", "customer_name", "region",
            "category", "sub_category", "sales", "quantity", "discount", "profit"]


def sample_data(n=2000, seed=42):
    """Generate a sample e-commerce dataset (used when no file is uploaded)."""
    rng = np.random.default_rng(seed)
    cats = {"Technology": ["Machines", "Copiers", "Phones", "Accessories"],
            "Furniture": ["Furnishings", "Bookcases", "Chairs", "Tables"],
            "Office Supplies": ["Storage", "Art"]}
    rows = []
    for i in range(n):
        cat = rng.choice(list(cats), p=[.5, .3, .2])
        rows.append({
            "Order ID": f"ORD-{i + 1:05d}",
            "Order Date": pd.Timestamp("2023-01-01") + pd.Timedelta(days=int(rng.integers(0, 365))),
            "Customer Name": rng.choice(["Deepa Mishra", "Anjali Gupta", "Pooja Iyer", "Meena Sharma",
                                         "Kavya Nair", "Pooja Rao", "Sanjay Reddy", "Karthik Das",
                                         "Divya Mishra", "Deepa Kumar", "Arun Raj", "Ravi Kumar"]),
            "Region": rng.choice(["West", "East", "North", "South"]),
            "Category": cat,
            "Sub-Category": rng.choice(cats[cat]),
            "Sales": round(float(rng.gamma(2, 450)), 2),
            "Quantity": int(rng.integers(1, 8)),
            "Discount": round(float(rng.choice([0, .05, .1, .15, .2, .3])), 2),
        })
    df = pd.DataFrame(rows)
    df["Profit"] = (df["Sales"] * (0.3 - df["Discount"]) + rng.normal(0, 30, n)).round(2)
    return df


def clean(df):
    """Standardise column names, fix types, drop duplicates / bad rows.
    Returns (clean_df, report_dict)."""
    report = {"rows_in": len(df)}
    df = df.copy()
    df.columns = (df.columns.str.strip().str.lower()
                  .str.replace(r"[\s\-]+", "_", regex=True))
    missing = [c for c in REQUIRED if c not in df.columns]
    if missing:
        raise ValueError("Missing required column(s): " + ", ".join(missing))
    df = df[REQUIRED]

    before = len(df)
    df = df.drop_duplicates()
    report["duplicates_removed"] = before - len(df)

    for c in ["sales", "quantity", "discount", "profit"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df["order_date"] = pd.to_datetime(df["order_date"], errors="coerce")
    for c in ["customer_name", "region", "category", "sub_category"]:
        df[c] = df[c].astype("string").str.strip().str.title()

    before = len(df)
    df = df.dropna(subset=["order_id", "order_date", "sales"])
    report["invalid_rows_removed"] = before - len(df)

    filled = int(df[["quantity", "discount", "profit"]].isna().sum().sum())
    df["quantity"] = df["quantity"].fillna(df["quantity"].median())
    df["discount"] = df["discount"].fillna(0)
    df["profit"] = df["profit"].fillna(df["profit"].median())
    for c in ["customer_name", "region", "category", "sub_category"]:
        filled += int(df[c].isna().sum())
        df[c] = df[c].fillna("Unknown")
    report["missing_filled"] = filled
    report["rows_out"] = len(df)
    return df.reset_index(drop=True), report


def _png(fig):
    buf = io.BytesIO()
    fig.tight_layout()
    fig.savefig(buf, format="png", dpi=110)
    plt.close(fig)
    return base64.b64encode(buf.getvalue()).decode()


def analyse(df):
    """Return KPI dict and a dict of base64 chart images."""
    sns.set_theme(style="whitegrid")
    if df.empty:
        return None, {}
    kpi = {
        "orders": f"{df['order_id'].nunique():,}",
        "sales": f"₹{df['sales'].sum():,.0f}",
        "profit": f"₹{df['profit'].sum():,.0f}",
        "discount": f"{df['discount'].mean() * 100:.1f}%",
        "top_category": df.groupby("category")["sales"].sum().idxmax(),
        "top_region": df.groupby("region")["sales"].sum().idxmax(),
    }
    charts = {}

    s = df.groupby("category")["sales"].sum().sort_values(ascending=False)
    fig, ax = plt.subplots(figsize=(5, 3.4))
    sns.barplot(x=s.index, y=s.values, color="#4C72B0", ax=ax)
    ax.set(title="Total Sales by Category", xlabel="", ylabel="Sales")
    charts["Total Sales by Category"] = _png(fig)

    m = df.groupby(df["order_date"].dt.to_period("M"))["sales"].sum()
    fig, ax = plt.subplots(figsize=(5, 3.4))
    ax.plot([str(p) for p in m.index], m.values, marker="o", color="#C44E52")
    ax.set(title="Monthly Sales Trend", ylabel="Sales")
    ax.tick_params(axis="x", rotation=60)
    charts["Monthly Sales Trend"] = _png(fig)

    r = df.groupby("region")["sales"].sum()
    fig, ax = plt.subplots(figsize=(5, 3.4))
    ax.pie(r.values, labels=r.index, autopct="%1.1f%%", startangle=90)
    ax.set_title("Sales Distribution by Region")
    charts["Sales Distribution by Region"] = _png(fig)

    fig, ax = plt.subplots(figsize=(5, 3.4))
    sns.scatterplot(data=df, x="discount", y="profit", alpha=.4, ax=ax)
    ax.set_title("Discount vs Profit")
    charts["Discount vs Profit"] = _png(fig)

    sc = df.groupby("sub_category")["sales"].sum().sort_values(ascending=False).head(10)
    fig, ax = plt.subplots(figsize=(5, 3.4))
    sns.barplot(x=sc.values, y=sc.index, color="#55A868", ax=ax)
    ax.set(title="Top Sub-Categories by Sales", xlabel="Sales", ylabel="")
    charts["Top Sub-Categories by Sales"] = _png(fig)

    tc = df.groupby("customer_name")["sales"].sum().sort_values(ascending=False).head(10)
    fig, ax = plt.subplots(figsize=(5, 3.4))
    sns.barplot(x=tc.values, y=tc.index, color="#8172B2", ax=ax)
    ax.set(title="Top 10 Customers by Sales", xlabel="Sales", ylabel="")
    charts["Top 10 Customers by Sales"] = _png(fig)
    return kpi, charts
